rm -rf ./output
mkdir output
cp -rf ./public/* ./output
