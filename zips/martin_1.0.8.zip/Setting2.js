import{s as t}from"./Setting.vue_vue_type_script_setup_true_lang.js";import{s as e}from"./Setting.vue_vue_type_script_setup_true_lang.js";import"./index.js";export{e as default};
